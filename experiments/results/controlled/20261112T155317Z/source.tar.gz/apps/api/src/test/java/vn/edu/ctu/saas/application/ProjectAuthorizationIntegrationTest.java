package vn.edu.ctu.saas.application;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static vn.edu.ctu.saas.application.ApplicationDtos.CreateCommentRequest;
import static vn.edu.ctu.saas.application.ApplicationDtos.CreateBoardRequest;
import static vn.edu.ctu.saas.application.ApplicationDtos.CreateColumnRequest;
import static vn.edu.ctu.saas.application.ApplicationDtos.CreateTaskRequest;
import static vn.edu.ctu.saas.application.ApplicationDtos.ChangeProjectStatusRequest;
import static vn.edu.ctu.saas.application.ApplicationDtos.ReorderColumnsRequest;
import static vn.edu.ctu.saas.application.ApplicationDtos.ReorderTaskItem;
import static vn.edu.ctu.saas.application.ApplicationDtos.ReorderTasksRequest;
import static vn.edu.ctu.saas.application.ApplicationDtos.SetProjectMemberRequest;
import static vn.edu.ctu.saas.application.ApplicationDtos.UpdateColumnRequest;
import static vn.edu.ctu.saas.application.ApplicationDtos.UpdateBoardRequest;
import static vn.edu.ctu.saas.application.ApplicationDtos.UpdateCommentRequest;
import static vn.edu.ctu.saas.application.ApplicationDtos.UpdateProjectRequest;
import static vn.edu.ctu.saas.application.ApplicationDtos.UpdateTaskRequest;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.sql.DataSource;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.postgresql.PostgreSQLContainer;
import com.fasterxml.jackson.databind.json.JsonMapper;
import vn.edu.ctu.saas.common.ConflictException;
import vn.edu.ctu.saas.common.NotFoundException;
import vn.edu.ctu.saas.control.TenantMembershipEntity;
import vn.edu.ctu.saas.control.TenantMembershipRepository;
import vn.edu.ctu.saas.notification.NotificationService;
import vn.edu.ctu.saas.storage.ResourceService;
import vn.edu.ctu.saas.storage.ResourceStorage;
import vn.edu.ctu.saas.tenant.ProjectRole;
import vn.edu.ctu.saas.tenant.ProjectStatus;
import vn.edu.ctu.saas.tenant.TenantAccessDeniedException;
import vn.edu.ctu.saas.tenant.TenantContext;
import vn.edu.ctu.saas.tenant.TenantContextHolder;
import vn.edu.ctu.saas.tenant.TenantDataSourceResolver;
import vn.edu.ctu.saas.tenant.TenantJdbcExecutor;
import vn.edu.ctu.saas.tenant.TenantPlacement;
import vn.edu.ctu.saas.tenant.TenantRole;

@Testcontainers(disabledWithoutDocker = true)
class ProjectAuthorizationIntegrationTest {
    private static final String APP_ROLE = "project_authz_app";
    private static final String ROLE_PASSWORD = "project-authz-password";

    private static final UUID TENANT_A = UUID.fromString("10000000-0000-0000-0000-000000000001");
    private static final UUID TENANT_B = UUID.fromString("20000000-0000-0000-0000-000000000002");
    private static final UUID MANAGER = UUID.fromString("30000000-0000-0000-0000-000000000001");
    private static final UUID MEMBER = UUID.fromString("30000000-0000-0000-0000-000000000002");
    private static final UUID VIEWER = UUID.fromString("30000000-0000-0000-0000-000000000003");
    private static final UUID OUTSIDER = UUID.fromString("30000000-0000-0000-0000-000000000004");
    private static final UUID FOREIGN_MANAGER = UUID.fromString("30000000-0000-0000-0000-000000000005");

    private static final UUID PROJECT_A = UUID.fromString("40000000-0000-0000-0000-000000000001");
    private static final UUID PROJECT_B = UUID.fromString("40000000-0000-0000-0000-000000000002");
    private static final UUID BOARD_A = UUID.fromString("50000000-0000-0000-0000-000000000001");
    private static final UUID BOARD_B = UUID.fromString("50000000-0000-0000-0000-000000000002");
    private static final UUID COLUMN_A = UUID.fromString("60000000-0000-0000-0000-000000000001");
    private static final UUID COLUMN_B = UUID.fromString("60000000-0000-0000-0000-000000000002");
    private static final UUID TASK_A = UUID.fromString("70000000-0000-0000-0000-000000000001");
    private static final UUID TASK_B = UUID.fromString("70000000-0000-0000-0000-000000000002");
    private static final UUID COMMENT_A = UUID.fromString("80000000-0000-0000-0000-000000000001");
    private static final UUID RESOURCE_A = UUID.fromString("90000000-0000-0000-0000-000000000001");
    private static final UUID RESOURCE_B = UUID.fromString("90000000-0000-0000-0000-000000000002");

    @Container
    static final PostgreSQLContainer POSTGRES = new PostgreSQLContainer("postgres:16-alpine")
            .withDatabaseName("project_authorization")
            .withUsername("postgres")
            .withPassword("postgres");

    private static JdbcTemplate adminJdbc;
    private static DriverManagerDataSource applicationDataSource;

    private TenantMembershipRepository tenantMemberships;
    private ProjectApplicationService service;
    private ResourceStorage resourceStorage;
    private ResourceService resourceService;
    private TenantJdbcExecutor tenantExecutor;

    @BeforeAll
    static void migrateAndCreateRuntimeRole() throws SQLException {
        Flyway.configure()
                .dataSource(POSTGRES.getJdbcUrl(), POSTGRES.getUsername(), POSTGRES.getPassword())
                .locations("classpath:db/migration/application")
                .load()
                .migrate();

        try (Connection connection = POSTGRES.createConnection(""); Statement statement = connection.createStatement()) {
            statement.execute("CREATE ROLE " + APP_ROLE + " LOGIN PASSWORD '" + ROLE_PASSWORD
                    + "' NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS");
            statement.execute("GRANT CONNECT ON DATABASE project_authorization TO " + APP_ROLE);
            statement.execute("GRANT USAGE ON SCHEMA public TO " + APP_ROLE);
            statement.execute("GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO " + APP_ROLE);
        }

        adminJdbc = new JdbcTemplate(new DriverManagerDataSource(
                POSTGRES.getJdbcUrl(), POSTGRES.getUsername(), POSTGRES.getPassword()));
        applicationDataSource = new DriverManagerDataSource(
                POSTGRES.getJdbcUrl(), APP_ROLE, ROLE_PASSWORD);
    }

    @BeforeEach
    void setUp() {
        adminJdbc.execute("TRUNCATE TABLE tenant_kanban_settings, projects, resources, audit_events, outbox_events CASCADE");
        seedProject(TENANT_A, PROJECT_A, BOARD_A, COLUMN_A, TASK_A, MANAGER, "Alpha project", "Alpha task");
        seedProject(TENANT_B, PROJECT_B, BOARD_B, COLUMN_B, TASK_B, FOREIGN_MANAGER, "Beta project", "Beta task");
        seedProjectMembership(TENANT_A, PROJECT_A, MEMBER, ProjectRole.MEMBER);
        seedProjectMembership(TENANT_A, PROJECT_A, VIEWER, ProjectRole.VIEWER);
        adminJdbc.update(
                "INSERT INTO comments(id,tenant_id,task_id,author_user_id,body) VALUES (?,?,?,?,?)",
                COMMENT_A, TENANT_A, TASK_A, MANAGER, "Seed comment");
        seedResource(TENANT_A, RESOURCE_A, TASK_A, MANAGER, "alpha-evidence.txt");
        seedResource(TENANT_B, RESOURCE_B, TASK_B, FOREIGN_MANAGER, "beta-secret.txt");

        tenantMemberships = mock(TenantMembershipRepository.class);
        tenantExecutor = new TenantJdbcExecutor(new TenantDataSourceResolver() {
            @Override
            public DataSource resolve(TenantContext ignored) {
                return applicationDataSource;
            }

            @Override
            public void evict(UUID ignored) {
                // The fixed Testcontainer data source has no per-tenant cache to evict.
            }
        });
        service = new ProjectApplicationService(tenantExecutor, JsonMapper.builder().findAndAddModules().build(), tenantMemberships);
        resourceStorage = mock(ResourceStorage.class);
        when(resourceStorage.createDownloadUrl(anyString(), any())).thenAnswer(invocation ->
                "https://storage.example.test/" + invocation.getArgument(0, String.class));
        when(resourceStorage.store(
                eq(TENANT_A), any(UUID.class), anyString(), anyString(), anyLong(), any()))
                .thenAnswer(invocation -> new ResourceStorage.StoredObject(
                        TENANT_A + "/" + invocation.getArgument(1, UUID.class) + "/uploaded.txt",
                        invocation.getArgument(4, Long.class)));
        resourceService = new ResourceService(tenantExecutor, resourceStorage);
    }

    @AfterEach
    void clearTenantContext() {
        TenantContextHolder.clear();
    }

    @Test
    void viewerCanReadButCannotCreateTaskOrCommentAndLeavesNoSideEffects() {
        useContext(VIEWER, TenantRole.MEMBER);

        assertThat(service.getBoard(BOARD_A).id()).isEqualTo(BOARD_A);
        assertThat(service.comments(TASK_A)).extracting(ApplicationDtos.CommentView::body)
                .containsExactly("Seed comment");
        assertThatThrownBy(() -> service.createTask(BOARD_A, createTask("Viewer task")))
                .isInstanceOf(TenantAccessDeniedException.class);
        assertThatThrownBy(() -> service.addComment(TASK_A, new CreateCommentRequest("Viewer comment")))
                .isInstanceOf(TenantAccessDeniedException.class);
        assertThatThrownBy(() -> service.createColumn(
                BOARD_A, new CreateColumnRequest("Viewer column", false, 0L)))
                .isInstanceOf(TenantAccessDeniedException.class);
        assertThat(resourceService.list()).extracting(ResourceService.ResourceView::id)
                .containsExactly(RESOURCE_A);
        assertThat(resourceService.downloadUrl(RESOURCE_A).url()).contains(RESOURCE_A.toString());
        assertThatThrownBy(() -> resourceService.downloadUrl(RESOURCE_B))
                .isInstanceOf(NotFoundException.class)
                .hasMessage("Resource not found");
        assertThatThrownBy(() -> resourceService.attach(RESOURCE_A, TASK_A))
                .isInstanceOf(TenantAccessDeniedException.class);
        assertThatThrownBy(() -> resourceService.delete(RESOURCE_A))
                .isInstanceOf(TenantAccessDeniedException.class);
        assertThatThrownBy(() -> resourceService.upload(
                "viewer.txt", "text/plain", 6, new ByteArrayInputStream("viewer".getBytes())))
                .isInstanceOf(TenantAccessDeniedException.class)
                .hasMessage("Project member role is required to upload resources");
        verify(resourceStorage, never()).store(any(), any(), anyString(), anyString(), anyLong(), any());

        assertThat(count("SELECT count(*) FROM tasks WHERE tenant_id=?", TENANT_A)).isEqualTo(1);
        assertThat(count("SELECT count(*) FROM board_columns WHERE tenant_id=?", TENANT_A)).isEqualTo(1);
        assertThat(count("SELECT count(*) FROM comments WHERE tenant_id=?", TENANT_A)).isEqualTo(1);
        assertThat(count("SELECT count(*) FROM audit_events WHERE tenant_id=?", TENANT_A)).isZero();
        assertThat(count("SELECT count(*) FROM outbox_events WHERE tenant_id=?", TENANT_A)).isZero();
    }

    @Test
    void memberCanCreateTaskAndCommentButCannotManageProject() {
        useContext(MEMBER, TenantRole.MEMBER);

        ApplicationDtos.TaskView createdTask = service.createTask(BOARD_A, createTask("Member task"));
        ApplicationDtos.CommentView createdComment = service.addComment(
                TASK_A, new CreateCommentRequest("Member comment"));
        ResourceService.ResourceView uploaded = resourceService.upload(
                "member.txt", "text/plain", 6, new ByteArrayInputStream("member".getBytes()));
        resourceService.attach(uploaded.id(), TASK_A);
        assertThat(createdTask.title()).isEqualTo("Member task");
        assertThat(createdComment.authorUserId()).isEqualTo(MEMBER);
        assertThat(resourceService.downloadUrl(uploaded.id()).url()).contains(uploaded.id().toString());
        assertThat(uploaded.storageKey()).startsWith(TENANT_A + "/");
        assertThatThrownBy(() -> resourceService.delete(uploaded.id()))
                .isInstanceOf(TenantAccessDeniedException.class)
                .hasMessage("Project manager role is required to delete this resource");

        assertThatThrownBy(() -> service.updateProject(
                PROJECT_A, new UpdateProjectRequest("Unauthorized rename", null)))
                .isInstanceOf(TenantAccessDeniedException.class);
        assertThat(projectName(PROJECT_A)).isEqualTo("Alpha project");
        assertThat(count("SELECT count(*) FROM audit_events WHERE tenant_id=?", TENANT_A)).isEqualTo(2);
        assertThat(count("SELECT count(*) FROM outbox_events WHERE tenant_id=?", TENANT_A)).isEqualTo(2);
    }

    @Test
    void managerCanManageProjectAndTask() {
        useContext(MANAGER, TenantRole.MEMBER);

        ApplicationDtos.ProjectView project = service.updateProject(
                PROJECT_A, new UpdateProjectRequest("Renamed by manager", "Updated"));
        ApplicationDtos.BoardView withColumn = service.createColumn(
                BOARD_A, new CreateColumnRequest("Review", false, 0L));
        UUID reviewColumnId = withColumn.columns().stream()
                .filter(column -> column.name().equals("Review"))
                .findFirst()
                .orElseThrow()
                .id();

        assertThat(withColumn.version()).isEqualTo(1);
        assertThatThrownBy(() -> service.createColumn(
                BOARD_A, new CreateColumnRequest("Stale", false, 0L)))
                .isInstanceOf(ConflictException.class)
                .hasMessage("Board columns were updated by another user");

        ApplicationDtos.BoardView renamed = service.updateColumn(
                BOARD_A, reviewColumnId, new UpdateColumnRequest("Verification", true, 1L));
        assertThat(renamed.columns()).filteredOn(column -> column.id().equals(reviewColumnId))
                .extracting(ApplicationDtos.ColumnView::completed)
                .containsExactly(true);
        ApplicationDtos.BoardView reordered = service.reorderColumns(
                BOARD_A, new ReorderColumnsRequest(java.util.List.of(reviewColumnId, COLUMN_A), renamed.version()));
        assertThat(reordered.columns()).extracting(ApplicationDtos.ColumnView::id)
                .containsExactly(reviewColumnId, COLUMN_A);
        assertThatThrownBy(() -> service.deleteColumn(BOARD_A, COLUMN_A, reordered.version()))
                .isInstanceOf(ConflictException.class)
                .hasMessage("Move or delete tasks before deleting this column");

        service.deleteTask(TASK_A);
        ApplicationDtos.BoardView finalBoard = service.deleteColumn(
                BOARD_A, reviewColumnId, reordered.version());
        assertThat(finalBoard.version()).isEqualTo(4);
        assertThat(finalBoard.columns()).extracting(ApplicationDtos.ColumnView::id)
                .containsExactly(COLUMN_A);
        assertThatThrownBy(() -> service.deleteColumn(BOARD_A, COLUMN_A, finalBoard.version()))
                .isInstanceOf(ConflictException.class)
                .hasMessage("A board must retain at least one column");

        assertThat(project.name()).isEqualTo("Renamed by manager");
        assertThat(projectName(PROJECT_A)).isEqualTo("Renamed by manager");
        assertThat(count("""
                SELECT count(*) FROM tasks WHERE tenant_id=? AND id=? AND deleted_at IS NOT NULL
                """, TENANT_A, TASK_A)).isOne();
        assertThat(count("SELECT count(*) FROM audit_events WHERE tenant_id=?", TENANT_A)).isEqualTo(6);
    }

    @Test
    void tenantOwnerWithoutProjectMembershipGetsNoImplicitProjectAccess() {
        useContext(OUTSIDER, TenantRole.OWNER);

        assertThat(service.listProjects()).isEmpty();
        assertThatThrownBy(() -> service.getBoard(BOARD_A))
                .isInstanceOf(TenantAccessDeniedException.class)
                .hasMessage("Insufficient project role");
        assertThatThrownBy(() -> service.updateProject(
                PROJECT_A, new UpdateProjectRequest("Owner bypass", null)))
                .isInstanceOf(TenantAccessDeniedException.class);

        assertThat(projectName(PROJECT_A)).isEqualTo("Alpha project");
        assertThat(count("SELECT count(*) FROM audit_events WHERE tenant_id=?", TENANT_A)).isZero();
    }

    @Test
    void revokedProjectMembershipImmediatelyRemovesProjectAccess() {
        useContext(VIEWER, TenantRole.MEMBER);
        assertThat(service.getBoard(BOARD_A).id()).isEqualTo(BOARD_A);

        adminJdbc.update(
                "DELETE FROM project_memberships WHERE tenant_id=? AND project_id=? AND user_id=?",
                TENANT_A, PROJECT_A, VIEWER);

        assertThat(service.listProjects()).isEmpty();
        assertThatThrownBy(() -> service.getBoard(BOARD_A))
                .isInstanceOf(TenantAccessDeniedException.class)
                .hasMessage("Insufficient project role");
        assertThat(count("SELECT count(*) FROM audit_events WHERE tenant_id=?", TENANT_A)).isZero();
        assertThat(count("SELECT count(*) FROM outbox_events WHERE tenant_id=?", TENANT_A)).isZero();
    }

    @Test
    void crossTenantIdsCannotReadOrMutateAndLeaveForeignRowsUntouched() {
        useContext(MANAGER, TenantRole.MEMBER);

        assertThatThrownBy(() -> service.getBoard(BOARD_B))
                .isInstanceOf(NotFoundException.class)
                .hasMessage("Board not found");
        assertThatThrownBy(() -> service.updateTask(
                TASK_B, new UpdateTaskRequest(
                        COLUMN_B, "Tampered", null, TaskPriority.MEDIUM, null, null, BigDecimal.ONE, 0)))
                .isInstanceOf(NotFoundException.class)
                .hasMessage("Task not found");
        assertThatThrownBy(() -> service.updateProject(
                PROJECT_B, new UpdateProjectRequest("Tampered", null)))
                .isInstanceOf(TenantAccessDeniedException.class)
                .hasMessage("Insufficient project role");
        assertThatThrownBy(() -> service.updateColumn(
                BOARD_A, COLUMN_B, new UpdateColumnRequest("Tampered", false, 0L)))
                .isInstanceOf(NotFoundException.class)
                .hasMessage("Board column not found");
        assertThat(resourceService.list()).extracting(ResourceService.ResourceView::id)
                .containsExactly(RESOURCE_A);
        assertThatThrownBy(() -> resourceService.downloadUrl(RESOURCE_B))
                .isInstanceOf(NotFoundException.class)
                .hasMessage("Resource not found");
        assertThatThrownBy(() -> resourceService.attach(RESOURCE_B, TASK_A))
                .isInstanceOf(NotFoundException.class)
                .hasMessage("Resource not found");
        assertThatThrownBy(() -> resourceService.attach(RESOURCE_A, TASK_B))
                .isInstanceOf(NotFoundException.class)
                .hasMessage("Task not found");
        assertThatThrownBy(() -> resourceService.delete(RESOURCE_B))
                .isInstanceOf(NotFoundException.class)
                .hasMessage("Resource not found");
        verify(resourceStorage, never()).createDownloadUrl(anyString(), any());
        verify(resourceStorage, never()).delete(anyString());

        assertThat(projectName(PROJECT_B)).isEqualTo("Beta project");
        assertThat(taskTitle(TASK_B)).isEqualTo("Beta task");
        assertThat(count("SELECT count(*) FROM audit_events")).isZero();
        assertThat(count("SELECT count(*) FROM outbox_events")).isZero();
        assertThat(count("SELECT count(*) FROM resources WHERE tenant_id=? AND id=?", TENANT_B, RESOURCE_B))
                .isEqualTo(1);
        assertThat(count("SELECT count(*) FROM task_resources WHERE tenant_id=? AND resource_id=?", TENANT_B, RESOURCE_B))
                .isEqualTo(1);
    }

    @Test
    void projectAuthorizationRunsBeforeTargetMembershipValidation() {
        useContext(VIEWER, TenantRole.MEMBER);

        assertThatThrownBy(() -> service.setProjectMember(
                PROJECT_A, OUTSIDER, new SetProjectMemberRequest(ProjectRole.VIEWER)))
                .isInstanceOf(TenantAccessDeniedException.class)
                .hasMessage("Insufficient project role");

        verifyNoInteractions(tenantMemberships);
        assertThat(count(
                "SELECT count(*) FROM project_memberships WHERE tenant_id=? AND project_id=? AND user_id=?",
                TENANT_A, PROJECT_A, OUTSIDER)).isZero();
    }

    @Test
    void managerCanAddAnActiveTenantMemberToProject() {
        useContext(MANAGER, TenantRole.ADMIN);
        TenantMembershipEntity activeTenantMember = new TenantMembershipEntity();
        activeTenantMember.setTenantId(TENANT_A);
        activeTenantMember.setUserId(OUTSIDER);
        activeTenantMember.setRole(TenantRole.MEMBER);
        activeTenantMember.setActive(true);
        when(tenantMemberships.findByTenantIdAndUserId(TENANT_A, OUTSIDER))
                .thenReturn(Optional.of(activeTenantMember));

        ApplicationDtos.ProjectMemberView result = service.setProjectMember(
                PROJECT_A, OUTSIDER, new SetProjectMemberRequest(ProjectRole.VIEWER));

        assertThat(result.userId()).isEqualTo(OUTSIDER);
        assertThat(result.role()).isEqualTo(ProjectRole.VIEWER);
        assertThat(count(
                "SELECT count(*) FROM project_memberships WHERE tenant_id=? AND project_id=? AND user_id=?",
                TENANT_A, PROJECT_A, OUTSIDER)).isEqualTo(1);
    }

    @Test
    void archivedProjectRemainsReadableButRejectsContentMutationsUntilRestored() {
        useContext(MANAGER, TenantRole.MEMBER);

        ApplicationDtos.ProjectView archived = service.changeProjectStatus(
                PROJECT_A, new ChangeProjectStatusRequest(ProjectStatus.ARCHIVED));

        assertThat(archived.status()).isEqualTo(ProjectStatus.ARCHIVED);
        assertThat(service.getBoard(BOARD_A).id()).isEqualTo(BOARD_A);
        assertThatThrownBy(() -> service.updateProject(
                PROJECT_A, new UpdateProjectRequest("Blocked rename", null)))
                .isInstanceOf(ConflictException.class)
                .hasMessage("Archived projects are read-only");
        assertThatThrownBy(() -> service.createTask(BOARD_A, createTask("Blocked task")))
                .isInstanceOf(ConflictException.class)
                .hasMessage("Archived projects are read-only");
        assertThatThrownBy(() -> resourceService.attach(RESOURCE_A, TASK_A))
                .isInstanceOf(ConflictException.class)
                .hasMessage("Archived projects are read-only");
        assertThat(projectName(PROJECT_A)).isEqualTo("Alpha project");
        assertThat(count("SELECT count(*) FROM tasks WHERE tenant_id=?", TENANT_A)).isEqualTo(1);

        ApplicationDtos.ProjectView restored = service.changeProjectStatus(
                PROJECT_A, new ChangeProjectStatusRequest(ProjectStatus.ACTIVE));
        ApplicationDtos.CommentView comment = service.addComment(
                TASK_A, new CreateCommentRequest("Mutation after restore"));

        assertThat(restored.status()).isEqualTo(ProjectStatus.ACTIVE);
        assertThat(comment.body()).isEqualTo("Mutation after restore");
        assertThat(count("SELECT count(*) FROM audit_events WHERE tenant_id=?", TENANT_A)).isEqualTo(3);
        assertThat(count("SELECT count(*) FROM outbox_events WHERE tenant_id=?", TENANT_A)).isEqualTo(3);
    }

    @Test
    void deletingProjectIsAuditedSoftDeleteAndHidesRetainedContent() {
        useContext(MANAGER, TenantRole.MEMBER);

        service.deleteProject(PROJECT_A);

        assertThat(projectStatus(PROJECT_A)).isEqualTo(ProjectStatus.DELETED.name());
        assertThat(service.listProjects()).isEmpty();
        assertThat(count("SELECT count(*) FROM boards WHERE tenant_id=? AND id=?", TENANT_A, BOARD_A)).isOne();
        assertThat(count("SELECT count(*) FROM tasks WHERE tenant_id=? AND id=?", TENANT_A, TASK_A)).isOne();
        assertThatThrownBy(() -> service.getBoard(BOARD_A))
                .isInstanceOf(TenantAccessDeniedException.class)
                .hasMessage("Insufficient project role");
        assertThat(count("SELECT count(*) FROM audit_events WHERE tenant_id=?", TENANT_A)).isOne();
        assertThat(count("SELECT count(*) FROM outbox_events WHERE tenant_id=?", TENANT_A)).isOne();
    }

    @Test
    void managerCanCreateRenameAndSoftDeleteAdditionalBoard() {
        useContext(MANAGER, TenantRole.MEMBER);

        ApplicationDtos.BoardView created = service.createBoard(
                PROJECT_A, new CreateBoardRequest("Release board"));
        assertThat(service.projectBoards(PROJECT_A)).hasSize(2);

        ApplicationDtos.BoardView renamed = service.updateBoard(
                created.id(), new UpdateBoardRequest("Launch board", created.version()));
        service.deleteBoard(renamed.id());

        assertThat(renamed.name()).isEqualTo("Launch board");
        assertThat(renamed.version()).isEqualTo(1);
        assertThat(service.projectBoards(PROJECT_A)).extracting(ApplicationDtos.BoardSummaryView::id)
                .containsExactly(BOARD_A);
        assertThat(count(
                "SELECT count(*) FROM boards WHERE tenant_id=? AND id=? AND deleted_at IS NOT NULL",
                TENANT_A, created.id())).isOne();
        assertThat(count("SELECT count(*) FROM audit_events WHERE tenant_id=?", TENANT_A)).isEqualTo(3);
    }

    @Test
    void managerCannotDeleteBoardThatStillContainsTasks() {
        useContext(MANAGER, TenantRole.MEMBER);

        assertThatThrownBy(() -> service.deleteBoard(BOARD_A))
                .isInstanceOf(ConflictException.class)
                .hasMessage("Move or delete all tasks before deleting this board");

        assertThat(count(
                "SELECT count(*) FROM boards WHERE tenant_id=? AND id=? AND deleted_at IS NULL",
                TENANT_A, BOARD_A)).isOne();
    }

    @Test
    void taskViewReturnsPersistedPriorityAndRealRelatedCounts() {
        useContext(MANAGER, TenantRole.MEMBER);
        ApplicationDtos.BoardView boardWithDone = service.createColumn(
                BOARD_A, new CreateColumnRequest("Completed", true, 0L));
        UUID completedColumnId = boardWithDone.columns().stream()
                .filter(ApplicationDtos.ColumnView::completed)
                .findFirst()
                .orElseThrow()
                .id();

        useContext(MEMBER, TenantRole.MEMBER);
        ApplicationDtos.TaskView parent = service.createTask(BOARD_A, new CreateTaskRequest(
                COLUMN_A, null, "Measured parent", null, TaskPriority.HIGH, null, null, null));
        ApplicationDtos.TaskView child = service.createTask(BOARD_A, new CreateTaskRequest(
                COLUMN_A, parent.id(), "Measured child", null, TaskPriority.LOW, null, null, null));
        service.moveTask(BOARD_A, child.id(), new ApplicationDtos.MoveTaskRequest(
                completedColumnId, BigDecimal.valueOf(1000), child.version()));
        service.addComment(parent.id(), new CreateCommentRequest("Counted comment"));

        ApplicationDtos.TaskView refreshed = service.getTask(parent.id());
        assertThat(refreshed.priority()).isEqualTo(TaskPriority.HIGH);
        assertThat(refreshed.subtaskCount()).isOne();
        assertThat(refreshed.completedSubtaskCount()).isOne();
        assertThat(refreshed.commentCount()).isOne();
    }

    @Test
    void taskBatchReorderIsAtomicAndManagerSoftDeleteIncludesOneLevelSubtasks() {
        useContext(MEMBER, TenantRole.MEMBER);
        ApplicationDtos.TaskView parent = service.createTask(BOARD_A, createTask("Parent task"));
        ApplicationDtos.TaskView child = service.createTask(BOARD_A, new CreateTaskRequest(
                COLUMN_A, parent.id(), "Child task", null, TaskPriority.MEDIUM, null, null, null));

        assertThatThrownBy(() -> service.createTask(BOARD_A, new CreateTaskRequest(
                COLUMN_A, child.id(), "Grandchild", null, TaskPriority.MEDIUM, null, null, null)))
                .isInstanceOf(ConflictException.class)
                .hasMessage("Subtasks can only have a top-level parent in the same board");
        ApplicationDtos.BoardView reordered = service.reorderTasks(BOARD_A, new ReorderTasksRequest(java.util.List.of(
                new ReorderTaskItem(parent.id(), COLUMN_A, BigDecimal.valueOf(2000), parent.version()),
                new ReorderTaskItem(child.id(), COLUMN_A, BigDecimal.valueOf(2100), child.version()))));
        BigDecimal parentPosition = reordered.tasks().stream()
                .filter(task -> task.id().equals(parent.id()))
                .findFirst()
                .orElseThrow()
                .position();
        assertThat(parentPosition).isEqualByComparingTo("2000");

        assertThatThrownBy(() -> service.reorderTasks(BOARD_A, new ReorderTasksRequest(java.util.List.of(
                new ReorderTaskItem(parent.id(), COLUMN_A, BigDecimal.ONE, parent.version()),
                new ReorderTaskItem(child.id(), COLUMN_A, BigDecimal.TWO, child.version() + 1)))))
                .isInstanceOf(ConflictException.class)
                .hasMessage("Task was updated by another user")
                .extracting(exception -> ((ConflictException) exception).fieldErrors().get("currentVersion"))
                .isEqualTo("1");
        assertThat(service.getTask(parent.id()).position()).isEqualByComparingTo("2000");

        useContext(MANAGER, TenantRole.MEMBER);
        service.deleteTask(parent.id());
        assertThatThrownBy(() -> service.getTask(parent.id())).isInstanceOf(NotFoundException.class);
        assertThatThrownBy(() -> service.getTask(child.id())).isInstanceOf(NotFoundException.class);
        assertThat(count("""
                SELECT count(*) FROM tasks WHERE tenant_id=? AND id IN (?,?) AND deleted_at IS NOT NULL
                """, TENANT_A, parent.id(), child.id())).isEqualTo(2);
    }

    @Test
    void commentAuthorCanEditAndManagerCanModerateWithSoftDeleteAudit() {
        useContext(MEMBER, TenantRole.MEMBER);
        ApplicationDtos.CommentView created = service.addComment(
                TASK_A, new CreateCommentRequest("Original body"));
        ApplicationDtos.CommentView edited = service.updateComment(
                created.id(), new UpdateCommentRequest("Author edit"));
        assertThat(edited.body()).isEqualTo("Author edit");

        useContext(VIEWER, TenantRole.MEMBER);
        assertThatThrownBy(() -> service.updateComment(
                created.id(), new UpdateCommentRequest("Viewer tamper")))
                .isInstanceOf(TenantAccessDeniedException.class)
                .hasMessage("Comment author or project manager role is required");

        useContext(MANAGER, TenantRole.MEMBER);
        assertThat(service.updateComment(created.id(), new UpdateCommentRequest("Manager moderation")).body())
                .isEqualTo("Manager moderation");
        service.deleteComment(created.id());
        assertThat(service.comments(TASK_A)).extracting(ApplicationDtos.CommentView::id)
                .containsExactly(COMMENT_A);
        assertThat(count(
                "SELECT count(*) FROM comments WHERE tenant_id=? AND id=? AND deleted_at IS NOT NULL",
                TENANT_A, created.id())).isOne();
        assertThat(count("SELECT count(*) FROM audit_events WHERE tenant_id=?", TENANT_A)).isEqualTo(4);
    }

    @Test
    void memberCanCreateValidatedLinkAndAttachDetachItAcrossResourceLibrary() {
        useContext(MEMBER, TenantRole.MEMBER);

        assertThatThrownBy(() -> resourceService.createLink("Unsafe", "javascript:alert(1)"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Resource link must use an absolute HTTP(S) URL");
        ResourceService.ResourceView link = resourceService.createLink(
                "Design reference", "https://example.test/design?q=tenant");
        resourceService.attach(link.id(), TASK_A);

        ResourceService.ResourceView attached = resourceService.list().stream()
                .filter(resource -> resource.id().equals(link.id()))
                .findFirst()
                .orElseThrow();
        assertThat(attached.kind()).isEqualTo(ResourceService.ResourceKind.LINK);
        assertThat(attached.taskIds()).containsExactly(TASK_A);
        assertThat(resourceService.downloadUrl(link.id()).url())
                .isEqualTo("https://example.test/design?q=tenant");

        resourceService.detach(link.id(), TASK_A);
        assertThat(resourceService.list().stream()
                .filter(resource -> resource.id().equals(link.id()))
                .findFirst().orElseThrow().taskIds()).isEmpty();
        resourceService.delete(link.id());

        assertThat(resourceService.list()).extracting(ResourceService.ResourceView::id)
                .doesNotContain(link.id());
        assertThat(count("""
                SELECT count(*) FROM resources WHERE tenant_id=? AND id=? AND deleted_at IS NOT NULL
                """, TENANT_A, link.id())).isOne();
        assertThat(count("SELECT count(*) FROM outbox_events WHERE tenant_id=?", TENANT_A)).isZero();
    }

    @Test
    void notificationPreferencesKeepInAppMandatoryAndPushSubscriptionIsIdempotentPerUser() {
        useContext(MEMBER, TenantRole.MEMBER);
        NotificationService notifications = new NotificationService(tenantExecutor);

        assertThat(notifications.preferences())
                .isEqualTo(new NotificationService.NotificationPreferences(true, true, false));
        assertThatThrownBy(() -> notifications.updatePreferences(
                new NotificationService.NotificationPreferences(false, true, false)))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Mandatory in-app notifications cannot be disabled");
        assertThat(notifications.updatePreferences(
                new NotificationService.NotificationPreferences(true, false, true)))
                .isEqualTo(new NotificationService.NotificationPreferences(true, false, true));

        NotificationService.PushSubscriptionRequest request = new NotificationService.PushSubscriptionRequest(
                "https://push.example.test/subscription/member", "public-key", "auth-secret");
        NotificationService.PushSubscriptionView first = notifications.addPushSubscription(request);
        NotificationService.PushSubscriptionView repeated = notifications.addPushSubscription(
                new NotificationService.PushSubscriptionRequest(
                        request.endpoint(), "rotated-public-key", "rotated-auth-secret"));
        assertThat(repeated.id()).isEqualTo(first.id());
        assertThat(notifications.pushSubscriptions()).extracting(NotificationService.PushSubscriptionView::id)
                .containsExactly(first.id());

        useContext(VIEWER, TenantRole.MEMBER);
        assertThatThrownBy(() -> notifications.removePushSubscription(first.id()))
                .isInstanceOf(NotFoundException.class)
                .hasMessage("Push subscription not found");
        useContext(MEMBER, TenantRole.MEMBER);
        notifications.removePushSubscription(first.id());
        assertThat(notifications.pushSubscriptions()).isEmpty();
    }


    @Test
    void pooledMetadataIsTypedAndStoredOnTheSharedTaskTable() {
        useContext(MANAGER, TenantRole.OWNER);
        configureKanban("OFF", 2);
        var task = service.createTask(BOARD_A, new CreateTaskRequest(COLUMN_A, null, "Typed metadata", null,
                TaskPriority.MEDIUM, null, null, null, java.util.Map.of("story_points", 5)));
        assertThat(task.customData()).containsEntry("story_points", 5);
        assertThatThrownBy(() -> service.createTask(BOARD_A, new CreateTaskRequest(COLUMN_A, null, "Bad metadata", null,
                TaskPriority.MEDIUM, null, null, null, java.util.Map.of("story_points", "not a number"))))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> service.createTask(BOARD_A, new CreateTaskRequest(COLUMN_A, null, "Foreign schema", null,
                TaskPriority.MEDIUM, null, null, null, java.util.Map.of("channel", "web"))))
                .isInstanceOf(IllegalArgumentException.class);
        assertThat(count("SELECT count(*) FROM tasks WHERE tenant_id=?", TENANT_A)).isEqualTo(2);
        assertThat(new JdbcTemplate(applicationDataSource).queryForObject(
                "SELECT count(*) FROM tenant_kanban_settings", Long.class)).isZero();
    }

    @Test
    void strictWipBlocksThirdTaskAndWarnAllowsIt() {
        useContext(MANAGER, TenantRole.OWNER);
        UUID doing = UUID.randomUUID();
        adminJdbc.update("INSERT INTO board_columns(id,tenant_id,board_id,name,position) VALUES (?,?,?,?,2000)",
                doing, TENANT_A, BOARD_A, "In Dev");
        configureKanban("STRICT", 2);
        for (int i=0; i<2; i++) service.createTask(BOARD_A,
                new CreateTaskRequest(doing,null,"Task " + i,null,TaskPriority.MEDIUM,null,null,null));
        assertThatThrownBy(() -> service.createTask(BOARD_A,
                new CreateTaskRequest(doing,null,"Third",null,TaskPriority.MEDIUM,null,null,null)))
                .isInstanceOf(vn.edu.ctu.saas.customization.WipLimitException.class);
        configureKanban("WARN", 2);
        service.createTask(BOARD_A,new CreateTaskRequest(doing,null,"Allowed warning",null,TaskPriority.MEDIUM,null,null,null));
        assertThat(count("SELECT count(*) FROM tasks WHERE board_column_id=?", doing)).isEqualTo(3);
    }

    @Test
    void concurrentCreatesCannotExceedStrictWip() throws Exception {
        UUID doing = UUID.randomUUID();
        adminJdbc.update("INSERT INTO board_columns(id,tenant_id,board_id,name,position) VALUES (?,?,?,?,2000)",
                doing,TENANT_A,BOARD_A,"In Dev");
        configureKanban("STRICT", 1);
        var threads = java.util.concurrent.Executors.newFixedThreadPool(2);
        var start = new java.util.concurrent.CountDownLatch(1);
        java.util.concurrent.Callable<Boolean> create = () -> {
            useContext(MANAGER,TenantRole.OWNER);
            try {
                start.await();
                service.createTask(BOARD_A,new CreateTaskRequest(doing,null,"Concurrent",null,TaskPriority.MEDIUM,null,null,null));
                return true;
            } catch (vn.edu.ctu.saas.customization.WipLimitException expected) { return false; }
            finally { TenantContextHolder.clear(); }
        };
        try {
            var one=threads.submit(create); var two=threads.submit(create); start.countDown();
            assertThat(java.util.List.of(one.get(20,java.util.concurrent.TimeUnit.SECONDS),two.get(20,java.util.concurrent.TimeUnit.SECONDS)))
                    .containsExactlyInAnyOrder(true,false);
        } finally { threads.shutdownNow(); }
        assertThat(count("SELECT count(*) FROM tasks WHERE board_column_id=?",doing)).isOne();
    }

    @Test
    void settingsRejectStaleUpdatesAndDoNotCrossTenantBoundaries() {
        var cache = new vn.edu.ctu.saas.customization.TenantConfigurationCache(
                mock(org.springframework.beans.factory.ObjectProvider.class), false);
        var settings = new vn.edu.ctu.saas.customization.PooledKanbanService(
                tenantExecutor,JsonMapper.builder().findAndAddModules().build(),cache);
        useContext(MANAGER,TenantRole.OWNER);
        var first = settings.update(new vn.edu.ctu.saas.customization.PooledKanbanService.View(
                new vn.edu.ctu.saas.customization.KanbanSettings("STRICT",2,"FULL",
                        java.util.List.of("Backlog","In Dev","Done"),java.util.List.of()),0));
        assertThat(first.version()).isEqualTo(1);
        assertThatThrownBy(() -> settings.update(new vn.edu.ctu.saas.customization.PooledKanbanService.View(first.settings(),0)))
                .isInstanceOf(ConflictException.class);
        useContext(MEMBER,TenantRole.MEMBER);
        assertThatThrownBy(() -> settings.update(new vn.edu.ctu.saas.customization.PooledKanbanService.View(first.settings(),1)))
                .isInstanceOf(TenantAccessDeniedException.class);
        TenantContextHolder.set(new TenantContext(FOREIGN_MANAGER,TENANT_B,"beta","STARTER",TenantPlacement.POOL,
                Set.of(TenantRole.OWNER),"request-b","correlation-b"));
        assertThat(settings.get().settings().wipMode()).isEqualTo("OFF");
    }

    private void configureKanban(String mode, int limit) {
        String json = "{\"wipMode\":\"" + mode + "\",\"wipLimit\":" + limit
                + ",\"cardStyle\":\"FULL\",\"defaultColumns\":[\"Backlog\",\"In Dev\",\"Done\"],"
                + "\"fields\":[{\"key\":\"story_points\",\"label\":\"Story points\",\"type\":\"NUMBER\",\"required\":false}]}";
        adminJdbc.update("INSERT INTO tenant_kanban_settings(tenant_id,settings) VALUES (?,CAST(? AS jsonb)) "
                + "ON CONFLICT (tenant_id) DO UPDATE SET settings=EXCLUDED.settings,version=tenant_kanban_settings.version+1",TENANT_A,json);
    }

    private static void seedProject(
            UUID tenantId,
            UUID projectId,
            UUID boardId,
            UUID columnId,
            UUID taskId,
            UUID managerId,
            String projectName,
            String taskTitle) {
        adminJdbc.update(
                "INSERT INTO projects(id,tenant_id,name,description,created_by) VALUES (?,?,?,?,?)",
                projectId, tenantId, projectName, null, managerId);
        seedProjectMembership(tenantId, projectId, managerId, ProjectRole.MANAGER);
        adminJdbc.update(
                "INSERT INTO boards(id,tenant_id,project_id,name) VALUES (?,?,?,?)",
                boardId, tenantId, projectId, "Kanban");
        adminJdbc.update(
                "INSERT INTO board_columns(id,tenant_id,board_id,name,position) VALUES (?,?,?,?,?)",
                columnId, tenantId, boardId, "To do", BigDecimal.valueOf(1000));
        adminJdbc.update("""
                INSERT INTO tasks(id,tenant_id,project_id,board_id,board_column_id,title,position,created_by)
                VALUES (?,?,?,?,?,?,?,?)
                """, taskId, tenantId, projectId, boardId, columnId, taskTitle, BigDecimal.valueOf(1000), managerId);
    }

    private static void seedProjectMembership(UUID tenantId, UUID projectId, UUID userId, ProjectRole role) {
        adminJdbc.update(
                "INSERT INTO project_memberships(id,tenant_id,project_id,user_id,role) VALUES (?,?,?,?,?)",
                UUID.randomUUID(), tenantId, projectId, userId, role.name());
    }

    private static void seedResource(
            UUID tenantId,
            UUID resourceId,
            UUID taskId,
            UUID uploader,
            String filename) {
        String storageKey = tenantId + "/" + resourceId + "/" + filename;
        adminJdbc.update("""
                INSERT INTO resources(id,tenant_id,original_name,storage_key,content_type,size_bytes,uploaded_by)
                VALUES (?,?,?,?,?,?,?)
                """, resourceId, tenantId, filename, storageKey, "text/plain", 12, uploader);
        adminJdbc.update("""
                INSERT INTO task_resources(id,tenant_id,task_id,resource_id)
                VALUES (?,?,?,?)
                """, UUID.randomUUID(), tenantId, taskId, resourceId);
    }

    private CreateTaskRequest createTask(String title) {
        return new CreateTaskRequest(COLUMN_A, null, title, null, TaskPriority.MEDIUM, null, null, null);
    }

    private void useContext(UUID userId, TenantRole tenantRole) {
        TenantContextHolder.set(new TenantContext(
                userId, TENANT_A, "alpha", "STARTER", TenantPlacement.POOL,
                Set.of(tenantRole), "request-test", "correlation-test"));
    }

    private long count(String sql, Object... args) {
        Long value = adminJdbc.queryForObject(sql, Long.class, args);
        return value == null ? 0 : value;
    }

    private String projectName(UUID projectId) {
        return adminJdbc.queryForObject("SELECT name FROM projects WHERE id=?", String.class, projectId);
    }

    private String projectStatus(UUID projectId) {
        return adminJdbc.queryForObject("SELECT status FROM projects WHERE id=?", String.class, projectId);
    }

    private String taskTitle(UUID taskId) {
        return adminJdbc.queryForObject("SELECT title FROM tasks WHERE id=?", String.class, taskId);
    }
}
