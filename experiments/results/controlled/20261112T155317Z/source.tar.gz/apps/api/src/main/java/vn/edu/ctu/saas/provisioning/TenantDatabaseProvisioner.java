package vn.edu.ctu.saas.provisioning;

import java.net.URI;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HexFormat;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import vn.edu.ctu.saas.config.AppProperties;
import vn.edu.ctu.saas.control.TenantEntity;
import vn.edu.ctu.saas.control.TenantPlacementEntity;
import vn.edu.ctu.saas.tenant.TenantPlacement;

@Component
public class TenantDatabaseProvisioner {
    public static final String LATEST_APPLICATION_SCHEMA_VERSION = "14";

    private final AppProperties properties;
    private final PlacementSecretCipher cipher;
    private final ProvisioningCheckpoint checkpoint;
    private final SecureRandom random = new SecureRandom();

    @Autowired
    public TenantDatabaseProvisioner(AppProperties properties, PlacementSecretCipher cipher) {
        this(properties, cipher, (stage, tenant, placement) -> {});
    }

    TenantDatabaseProvisioner(
            AppProperties properties,
            PlacementSecretCipher cipher,
            ProvisioningCheckpoint checkpoint) {
        this.properties = properties;
        this.cipher = cipher;
        this.checkpoint = checkpoint;
    }

    /**
     * Allocates deterministic placement metadata and a stable encrypted runtime
     * credential. The worker persists this metadata before external DDL starts,
     * so a retry never rotates a password whose successful result was not yet
     * finalized in the control database.
     */
    public void prepare(TenantEntity tenant, TenantPlacementEntity placement) {
        if (placement.getPlacementType() == TenantPlacement.POOL) {
            setOrVerifyDatabaseName(placement, databaseName(properties.datasource().pool().jdbcUrl()));
            setOrVerifySchemaName(placement, "public");
            return;
        }

        String suffix = tenant.getId().toString().replace("-", "");
        boolean schemaPlacement = placement.getPlacementType() == TenantPlacement.SCHEMA_PER_TENANT;
        String database = schemaPlacement
                ? databaseName(properties.datasource().schema().jdbcUrl())
                : identifier("tenant_" + suffix);
        String runtimeRole = identifier(schemaPlacement
                ? "tenant_" + suffix + "_app"
                : "tenant_" + suffix.substring(0, 20) + "_app");
        String schemaName = schemaPlacement ? identifier("tenant_" + suffix) : "public";
        JdbcEndpoint endpoint = endpoint(schemaPlacement
                ? properties.datasource().schema().jdbcUrl()
                : properties.provisioning().adminUrl());
        setOrVerify(placement.getDatabaseHost(), endpoint.host(), "database host");
        setOrVerify(placement.getDatabasePort(), endpoint.port(), "database port");
        setOrVerify(placement.getDatabaseName(), database, "database name");
        setOrVerify(placement.getDatabaseUsername(), runtimeRole, "database username");
        setOrVerify(placement.getSchemaName(), schemaName, "schema name");
        placement.setDatabaseHost(endpoint.host());
        placement.setDatabasePort(endpoint.port());
        placement.setDatabaseName(database);
        placement.setDatabaseUsername(runtimeRole);
        placement.setSchemaName(schemaName);
        if (placement.getEncryptedPassword() == null) {
            placement.setEncryptedPassword(cipher.encrypt(randomPassword()));
        } else {
            runtimePassword(placement);
        }
    }

    public void provision(TenantEntity tenant, TenantPlacementEntity placement) {
        prepare(tenant, placement);
        if (placement.getPlacementType() == TenantPlacement.POOL) {
            placement.setSchemaVersion(migratePool());
            return;
        }
        String database = identifier(placement.getDatabaseName());
        String runtimeRole = identifier(placement.getDatabaseUsername());
        String runtimePassword = runtimePassword(placement);
        if (placement.getPlacementType() == TenantPlacement.SCHEMA_PER_TENANT) {
            createSharedDatabase(database);
            createRole(runtimeRole, runtimePassword);
            createSchema(database, identifier(placement.getSchemaName()), runtimeRole);
        } else {
            createRoleAndDatabase(database, runtimeRole, runtimePassword);
        }
        checkpoint.reached(ProvisioningStage.DATABASE_READY, tenant, placement);
        String tenantUrl = withDatabase(properties.provisioning().adminUrl(), database);
        String schemaVersion = migrate(
                tenantUrl, properties.provisioning().adminUsername(), properties.provisioning().adminPassword(),
                identifier(placement.getSchemaName()));
        checkpoint.reached(ProvisioningStage.APPLICATION_MIGRATED, tenant, placement);
        grantRuntime(tenantUrl, runtimeRole, identifier(placement.getSchemaName()));
        placement.setSchemaVersion(schemaVersion);
        checkpoint.reached(ProvisioningStage.READY_TO_FINALIZE, tenant, placement);
    }

    public void rollback(TenantEntity tenant, TenantPlacementEntity placement) {
        if (placement.getPlacementType() == TenantPlacement.POOL) return;
        String suffix = tenant.getId().toString().replace("-", "");
        String database = placement.getPlacementType() == TenantPlacement.SCHEMA_PER_TENANT
                ? databaseName(properties.datasource().schema().jdbcUrl())
                : identifier("tenant_" + suffix);
        String runtimeRole = identifier(placement.getPlacementType() == TenantPlacement.SCHEMA_PER_TENANT
                ? "tenant_" + suffix + "_app"
                : "tenant_" + suffix.substring(0, 20) + "_app");
        if (placement.getPlacementType() == TenantPlacement.SCHEMA_PER_TENANT) {
            String schemaName = identifier("tenant_" + suffix);
            try (Connection connection = DriverManager.getConnection(
                    withDatabase(properties.provisioning().adminUrl(), database),
                    properties.provisioning().adminUsername(), properties.provisioning().adminPassword());
             Statement statement = connection.createStatement()) {
                statement.execute("DROP SCHEMA IF EXISTS " + schemaName + " CASCADE");
                statement.execute("DROP OWNED BY " + runtimeRole);
            } catch (SQLException exception) {
                throw new IllegalStateException("Failed to roll back tenant schema: " + exception.getMessage(), exception);
            }
            try (Connection connection = adminConnection(); Statement statement = connection.createStatement()) {
                statement.execute("REVOKE ALL ON DATABASE " + database + " FROM " + runtimeRole);
            } catch (SQLException exception) {
                throw new IllegalStateException("Failed to revoke tenant schema database access", exception);
            }
            dropRole(runtimeRole);
            return;
        }
        try (Connection connection = adminConnection(); Statement statement = connection.createStatement()) {
            connection.setAutoCommit(true);
            statement.execute("DROP DATABASE IF EXISTS " + database + " WITH (FORCE)");
            statement.execute("DROP ROLE IF EXISTS " + runtimeRole);
        } catch (SQLException exception) {
            throw new IllegalStateException(
                    "Failed to roll back tenant database: " + exception.getMessage(), exception);
        }
    }

    private String migratePool() {
        AppProperties.Datasource.Pool pool = properties.datasource().pool();
        String adminUrl = withDatabase(properties.provisioning().adminUrl(), databaseName(pool.jdbcUrl()));
        String schemaVersion = migrate(
                adminUrl, properties.provisioning().adminUsername(), properties.provisioning().adminPassword(), "public");
        grantRuntime(adminUrl, identifier(pool.username()), "public");
        return schemaVersion;
    }

    private String migrate(String url, String username, String password, String schemaName) {
        Flyway flyway = Flyway.configure()
                .dataSource(url, username, password)
                .defaultSchema(schemaName)
                .schemas(schemaName)
                .createSchemas(false)
                .locations("classpath:db/migration/application")
                .validateMigrationNaming(true)
                .load();
        flyway.migrate();
        var current = flyway.info().current();
        String schemaVersion = current == null || current.getVersion() == null
                ? null
                : current.getVersion().getVersion();
        if (!LATEST_APPLICATION_SCHEMA_VERSION.equals(schemaVersion)) {
            throw new IllegalStateException("Unexpected application schema version " + schemaVersion);
        }
        return schemaVersion;
    }

    private void createRole(String runtimeRole, String password) {
        try (Connection connection = adminConnection(); Statement statement = connection.createStatement()) {
            connection.setAutoCommit(true);
            if (!roleExists(connection, runtimeRole)) {
                statement.execute("CREATE ROLE " + runtimeRole + " LOGIN PASSWORD '" + password
                        + "' NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS");
            } else {
                statement.execute("ALTER ROLE " + runtimeRole + " PASSWORD '" + password + "'");
            }
        } catch (SQLException exception) {
            throw new IllegalStateException("Failed to create tenant runtime role", exception);
        }
    }

    private void createSharedDatabase(String database) {
        try (Connection connection = adminConnection(); Statement statement = connection.createStatement()) {
            connection.setAutoCommit(true);
            if (!databaseExists(connection, database)) {
                statement.execute("CREATE DATABASE " + database + " OWNER "
                        + identifier(properties.provisioning().adminUsername()));
            }
            statement.execute("REVOKE ALL ON DATABASE " + database + " FROM PUBLIC");
        } catch (SQLException exception) {
            throw new IllegalStateException("Failed to prepare shared schema database", exception);
        }
    }

    private void createSchema(String database, String schemaName, String runtimeRole) {
        String databaseUrl = withDatabase(properties.provisioning().adminUrl(), database);
        try (Connection connection = DriverManager.getConnection(
                databaseUrl, properties.provisioning().adminUsername(), properties.provisioning().adminPassword());
             Statement statement = connection.createStatement()) {
            statement.execute("REVOKE ALL ON SCHEMA public FROM PUBLIC");
            statement.execute("CREATE SCHEMA IF NOT EXISTS " + schemaName
                    + " AUTHORIZATION " + identifier(properties.provisioning().adminUsername()));
            statement.execute("REVOKE ALL ON SCHEMA " + schemaName + " FROM PUBLIC");
            statement.execute("GRANT USAGE ON SCHEMA " + schemaName + " TO " + runtimeRole);
        } catch (SQLException exception) {
            throw new IllegalStateException("Failed to create tenant schema", exception);
        }
        try (Connection connection = adminConnection(); Statement statement = connection.createStatement()) {
            statement.execute("GRANT CONNECT ON DATABASE " + database + " TO " + runtimeRole);
        } catch (SQLException exception) {
            throw new IllegalStateException("Failed to grant tenant schema database access", exception);
        }
    }

    private void createRoleAndDatabase(String database, String runtimeRole, String password) {
        try (Connection connection = adminConnection()) {
            connection.setAutoCommit(true);
            if (!roleExists(connection, runtimeRole)) {
                try (Statement statement = connection.createStatement()) {
                    statement.execute("CREATE ROLE " + runtimeRole + " LOGIN PASSWORD '" + password + "' NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS");
                }
            } else {
                // Reapply the stable prepared credential so a partial prior
                // attempt and the control-plane placement cannot drift apart.
                try (Statement statement = connection.createStatement()) {
                    statement.execute("ALTER ROLE " + runtimeRole + " PASSWORD '" + password + "'");
                }
            }
            if (!databaseExists(connection, database)) {
                try (Statement statement = connection.createStatement()) {
                    statement.execute("CREATE DATABASE " + database + " OWNER " + identifier(properties.provisioning().adminUsername()));
                }
            }
            try (Statement statement = connection.createStatement()) {
                statement.execute("GRANT CONNECT ON DATABASE " + database + " TO " + runtimeRole);
            }
        } catch (SQLException exception) {
            throw new IllegalStateException("Failed to create tenant database", exception);
        }
    }

    private void grantRuntime(String databaseUrl, String runtimeRole, String schemaName) {
        try (Connection connection = DriverManager.getConnection(
                databaseUrl, properties.provisioning().adminUsername(), properties.provisioning().adminPassword());
             Statement statement = connection.createStatement()) {
            statement.execute("GRANT USAGE ON SCHEMA " + schemaName + " TO " + runtimeRole);
            statement.execute("GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA " + schemaName + " TO " + runtimeRole);
            statement.execute("GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA " + schemaName + " TO " + runtimeRole);
            statement.execute("ALTER DEFAULT PRIVILEGES IN SCHEMA " + schemaName
                    + " GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO " + runtimeRole);
        } catch (SQLException exception) {
            throw new IllegalStateException("Failed to grant tenant runtime privileges", exception);
        }
    }

    private void dropRole(String runtimeRole) {
        try (Connection connection = adminConnection(); Statement statement = connection.createStatement()) {
            statement.execute("DROP ROLE IF EXISTS " + runtimeRole);
        } catch (SQLException exception) {
            throw new IllegalStateException("Failed to drop tenant runtime role", exception);
        }
    }

    private Connection adminConnection() throws SQLException {
        return DriverManager.getConnection(
                properties.provisioning().adminUrl(),
                properties.provisioning().adminUsername(),
                properties.provisioning().adminPassword());
    }

    private boolean roleExists(Connection connection, String role) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT 1 FROM pg_roles WHERE rolname = ?")) {
            statement.setString(1, role);
            try (ResultSet result = statement.executeQuery()) { return result.next(); }
        }
    }

    private boolean databaseExists(Connection connection, String database) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT 1 FROM pg_database WHERE datname = ?")) {
            statement.setString(1, database);
            try (ResultSet result = statement.executeQuery()) { return result.next(); }
        }
    }

    private String randomPassword() {
        byte[] bytes = new byte[32];
        random.nextBytes(bytes);
        return HexFormat.of().formatHex(bytes);
    }

    private String runtimePassword(TenantPlacementEntity placement) {
        String password = cipher.decrypt(placement.getEncryptedPassword());
        if (!password.matches("[0-9a-f]{64}")) {
            throw new IllegalStateException("Invalid generated tenant runtime credential");
        }
        return password;
    }

    private void setOrVerifyDatabaseName(TenantPlacementEntity placement, String expected) {
        setOrVerify(placement.getDatabaseName(), expected, "database name");
        placement.setDatabaseName(expected);
    }

    private void setOrVerifySchemaName(TenantPlacementEntity placement, String expected) {
        setOrVerify(placement.getSchemaName(), expected, "schema name");
        placement.setSchemaName(expected);
    }

    private void setOrVerify(Object current, Object expected, String field) {
        if (current != null && !current.equals(expected)) {
            throw new IllegalStateException("Tenant placement " + field + " does not match its deterministic value");
        }
    }

    private String identifier(String value) {
        if (value == null || !value.matches("[a-z_][a-z0-9_]{0,62}")) {
            throw new IllegalArgumentException("Unsafe PostgreSQL identifier");
        }
        return value;
    }

    private String databaseName(String jdbcUrl) {
        int query = jdbcUrl.indexOf('?');
        String clean = query >= 0 ? jdbcUrl.substring(0, query) : jdbcUrl;
        return clean.substring(clean.lastIndexOf('/') + 1);
    }

    private String withDatabase(String jdbcUrl, String database) {
        int query = jdbcUrl.indexOf('?');
        String suffix = query >= 0 ? jdbcUrl.substring(query) : "";
        String clean = query >= 0 ? jdbcUrl.substring(0, query) : jdbcUrl;
        return clean.substring(0, clean.lastIndexOf('/') + 1) + database + suffix;
    }

    private JdbcEndpoint endpoint(String jdbcUrl) {
        URI uri = URI.create(jdbcUrl.substring("jdbc:".length()));
        return new JdbcEndpoint(uri.getHost(), uri.getPort() < 0 ? 5432 : uri.getPort());
    }

    private record JdbcEndpoint(String host, int port) {}

    enum ProvisioningStage {
        DATABASE_READY,
        APPLICATION_MIGRATED,
        READY_TO_FINALIZE
    }

    @FunctionalInterface
    interface ProvisioningCheckpoint {
        void reached(ProvisioningStage stage, TenantEntity tenant, TenantPlacementEntity placement);
    }
}
