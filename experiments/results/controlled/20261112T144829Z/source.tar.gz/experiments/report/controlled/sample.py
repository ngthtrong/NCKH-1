import json,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
stop,out=map(Path,sys.argv[1:])
with out.open('w') as f:
 while not stop.exists():
  r=subprocess.run(['docker','stats','--no-stream','--format','{{json .}}','nckh-experiment-api-1','nckh-experiment-postgres-1','nckh-experiment-redis-1'],capture_output=True,text=True)
  f.write(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'data':[json.loads(s) for s in r.stdout.splitlines() if s.startswith('{')],'error':r.stderr.strip()})+'\n');f.flush();time.sleep(3)
